var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "28075",
        "ok": "27649",
        "ko": "426"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "45"
    },
    "maxResponseTime": {
        "total": "2083808",
        "ok": "4782",
        "ko": "2083808"
    },
    "meanResponseTime": {
        "total": "1508",
        "ok": "471",
        "ko": "68844"
    },
    "standardDeviation": {
        "total": "46484",
        "ok": "629",
        "ko": "371175"
    },
    "percentiles1": {
        "total": "308",
        "ok": "306",
        "ko": "407"
    },
    "percentiles2": {
        "total": "529",
        "ok": "529",
        "ko": "555"
    },
    "percentiles3": {
        "total": "2243",
        "ok": "2249",
        "ko": "847"
    },
    "percentiles4": {
        "total": "60339",
        "ok": "3220",
        "ko": "2082637"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 24420,
    "percentage": 86.9813000890472
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1060,
    "percentage": 3.77560106856634
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2169,
    "percentage": 7.725734639358859
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 426,
    "percentage": 1.5173642030276047
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.13",
        "ok": "7.02",
        "ko": "0.11"
    }
},
contents: {
"group_login-73596745": {
          type: "GROUP",
name: "Login",
path: "Login",
pathFormatted: "group_login-73596745",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "3110",
        "ok": "3101",
        "ko": "9"
    },
    "minResponseTime": {
        "total": "509",
        "ok": "509",
        "ko": "2081987"
    },
    "maxResponseTime": {
        "total": "2087337",
        "ok": "2087337",
        "ko": "2085552"
    },
    "meanResponseTime": {
        "total": "11391",
        "ok": "5376",
        "ko": "2083894"
    },
    "standardDeviation": {
        "total": "123517",
        "ok": "52901",
        "ko": "1153"
    },
    "percentiles1": {
        "total": "4464",
        "ok": "4455",
        "ko": "2083848"
    },
    "percentiles2": {
        "total": "5531",
        "ok": "5523",
        "ko": "2084838"
    },
    "percentiles3": {
        "total": "6643",
        "ok": "6617",
        "ko": "2085552"
    },
    "percentiles4": {
        "total": "7592",
        "ok": "7430",
        "ko": "2085552"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 49,
    "percentage": 1.5755627009646302
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 3052,
    "percentage": 98.13504823151126
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 9,
    "percentage": 0.28938906752411575
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
},
contents: {
"req_000-get-home-1681177011": {
        type: "REQUEST",
        name: "000:GET Home",
path: "Login / 000:GET Home",
pathFormatted: "req_login---000-get--239977541",
stats: {
    "name": "000:GET Home",
    "numberOfRequests": {
        "total": "3110",
        "ok": "3110",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "192",
        "ok": "192",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles4": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3110,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "-"
    }
}
    },"req_000-get-home-re--557125222": {
        type: "REQUEST",
        name: "000:GET Home Redirect 1",
path: "Login / 000:GET Home Redirect 1",
pathFormatted: "req_login---000-get-1689606802",
stats: {
    "name": "000:GET Home Redirect 1",
    "numberOfRequests": {
        "total": "3110",
        "ok": "3108",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "2081985"
    },
    "maxResponseTime": {
        "total": "2082250",
        "ok": "1084",
        "ko": "2082250"
    },
    "meanResponseTime": {
        "total": "1631",
        "ok": "292",
        "ko": "2082118"
    },
    "standardDeviation": {
        "total": "52777",
        "ok": "191",
        "ko": "133"
    },
    "percentiles1": {
        "total": "262",
        "ok": "262",
        "ko": "2082250"
    },
    "percentiles2": {
        "total": "414",
        "ok": "415",
        "ko": "2082250"
    },
    "percentiles3": {
        "total": "652",
        "ok": "653",
        "ko": "2082250"
    },
    "percentiles4": {
        "total": "859",
        "ok": "839",
        "ko": "2082250"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3070,
    "percentage": 98.71382636655949
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 38,
    "percentage": 1.2218649517684887
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0.06430868167202572
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
}
    },"req_002-post-index---733441038": {
        type: "REQUEST",
        name: "002:POST index.php/auth/validate",
path: "Login / 002:POST index.php/auth/validate",
pathFormatted: "req_login---002-pos--759643654",
stats: {
    "name": "002:POST index.php/auth/validate",
    "numberOfRequests": {
        "total": "3108",
        "ok": "3102",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "235",
        "ok": "235",
        "ko": "2082244"
    },
    "maxResponseTime": {
        "total": "2083808",
        "ok": "4782",
        "ko": "2083808"
    },
    "meanResponseTime": {
        "total": "5880",
        "ok": "1862",
        "ko": "2083065"
    },
    "standardDeviation": {
        "total": "91360",
        "ok": "959",
        "ko": "556"
    },
    "percentiles1": {
        "total": "1899",
        "ok": "1897",
        "ko": "2083470"
    },
    "percentiles2": {
        "total": "2601",
        "ok": "2596",
        "ko": "2083477"
    },
    "percentiles3": {
        "total": "3422",
        "ok": "3405",
        "ko": "2083808"
    },
    "percentiles4": {
        "total": "4041",
        "ok": "3981",
        "ko": "2083808"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 546,
    "percentage": 17.56756756756757
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 409,
    "percentage": 13.159588159588159
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2147,
    "percentage": 69.07979407979408
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0.19305019305019305
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
}
    },"req_002-post-index---530413061": {
        type: "REQUEST",
        name: "002:POST index.php/auth/validate Redirect 1",
path: "Login / 002:POST index.php/auth/validate Redirect 1",
pathFormatted: "req_login---002-pos--1523136781",
stats: {
    "name": "002:POST index.php/auth/validate Redirect 1",
    "numberOfRequests": {
        "total": "3102",
        "ok": "3101",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "2081713"
    },
    "maxResponseTime": {
        "total": "2081713",
        "ok": "1365",
        "ko": "2081713"
    },
    "meanResponseTime": {
        "total": "1067",
        "ok": "396",
        "ko": "2081713"
    },
    "standardDeviation": {
        "total": "37364",
        "ok": "245",
        "ko": "0"
    },
    "percentiles1": {
        "total": "360",
        "ok": "358",
        "ko": "2081713"
    },
    "percentiles2": {
        "total": "561",
        "ok": "563",
        "ko": "2081713"
    },
    "percentiles3": {
        "total": "841",
        "ok": "843",
        "ko": "2081713"
    },
    "percentiles4": {
        "total": "1043",
        "ok": "1058",
        "ko": "2081713"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2894,
    "percentage": 93.29464861379755
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 198,
    "percentage": 6.382978723404255
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9,
    "percentage": 0.2901353965183753
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.032237266279819474
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
}
    }
}

     },"group_addemployee-1887058511": {
          type: "GROUP",
name: "AddEmployee",
path: "AddEmployee",
pathFormatted: "group_addemployee-1887058511",
stats: {
    "name": "AddEmployee",
    "numberOfRequests": {
        "total": "298",
        "ok": "297",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "738",
        "ok": "738",
        "ko": "2082590"
    },
    "maxResponseTime": {
        "total": "2082590",
        "ok": "10314",
        "ko": "2082590"
    },
    "meanResponseTime": {
        "total": "12218",
        "ok": "5247",
        "ko": "2082590"
    },
    "standardDeviation": {
        "total": "120155",
        "ok": "2178",
        "ko": "0"
    },
    "percentiles1": {
        "total": "5809",
        "ok": "5796",
        "ko": "2082590"
    },
    "percentiles2": {
        "total": "7007",
        "ok": "7000",
        "ko": "2082590"
    },
    "percentiles3": {
        "total": "7923",
        "ok": "7897",
        "ko": "2082590"
    },
    "percentiles4": {
        "total": "8946",
        "ok": "8724",
        "ko": "2082590"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 297,
    "percentage": 99.66442953020133
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.33557046979865773
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "0"
    }
},
contents: {
"req_015-get-index-p-1954806461": {
        type: "REQUEST",
        name: "015:GET index.php/pim/viewPimModule",
path: "AddEmployee / 015:GET index.php/pim/viewPimModule",
pathFormatted: "req_addemployee---0-1188656699",
stats: {
    "name": "015:GET index.php/pim/viewPimModule",
    "numberOfRequests": {
        "total": "298",
        "ok": "298",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "978",
        "ok": "978",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "309",
        "ok": "309",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "282",
        "ok": "282",
        "ko": "-"
    },
    "percentiles2": {
        "total": "432",
        "ok": "432",
        "ko": "-"
    },
    "percentiles3": {
        "total": "626",
        "ok": "628",
        "ko": "-"
    },
    "percentiles4": {
        "total": "844",
        "ok": "844",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 295,
    "percentage": 98.99328859060402
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3,
    "percentage": 1.006711409395973
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_015-get-index-p-1057588816": {
        type: "REQUEST",
        name: "015:GET index.php/pim/viewPimModule Redirect 1",
path: "AddEmployee / 015:GET index.php/pim/viewPimModule Redirect 1",
pathFormatted: "req_addemployee---0-964202514",
stats: {
    "name": "015:GET index.php/pim/viewPimModule Redirect 1",
    "numberOfRequests": {
        "total": "298",
        "ok": "297",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "46",
        "ok": "46",
        "ko": "2082081"
    },
    "maxResponseTime": {
        "total": "2082081",
        "ok": "1206",
        "ko": "2082081"
    },
    "meanResponseTime": {
        "total": "7388",
        "ok": "402",
        "ko": "2082081"
    },
    "standardDeviation": {
        "total": "120386",
        "ok": "246",
        "ko": "0"
    },
    "percentiles1": {
        "total": "372",
        "ok": "371",
        "ko": "2082081"
    },
    "percentiles2": {
        "total": "569",
        "ok": "566",
        "ko": "2082081"
    },
    "percentiles3": {
        "total": "868",
        "ok": "868",
        "ko": "2082081"
    },
    "percentiles4": {
        "total": "1123",
        "ok": "1122",
        "ko": "2082081"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 274,
    "percentage": 91.94630872483222
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 22,
    "percentage": 7.38255033557047
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1,
    "percentage": 0.33557046979865773
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.33557046979865773
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "0"
    }
}
    },"req_022-get-index-p-1836280013": {
        type: "REQUEST",
        name: "022:GET index.php/pim/addEmployee",
path: "AddEmployee / 022:GET index.php/pim/addEmployee",
pathFormatted: "req_addemployee---0--850547765",
stats: {
    "name": "022:GET index.php/pim/addEmployee",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1140",
        "ok": "1140",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "384",
        "ok": "384",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "236",
        "ok": "236",
        "ko": "-"
    },
    "percentiles1": {
        "total": "349",
        "ok": "349",
        "ko": "-"
    },
    "percentiles2": {
        "total": "552",
        "ok": "552",
        "ko": "-"
    },
    "percentiles3": {
        "total": "807",
        "ok": "807",
        "ko": "-"
    },
    "percentiles4": {
        "total": "987",
        "ok": "987",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 280,
    "percentage": 94.27609427609428
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 17,
    "percentage": 5.723905723905724
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_026-get-core-va-1434354855": {
        type: "REQUEST",
        name: "026:GET core/validation/unique",
path: "AddEmployee / 026:GET core/validation/unique",
pathFormatted: "req_addemployee---0--999468439",
stats: {
    "name": "026:GET core/validation/unique",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "961",
        "ok": "961",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "302",
        "ok": "302",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "183",
        "ok": "183",
        "ko": "-"
    },
    "percentiles1": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles2": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles3": {
        "total": "613",
        "ok": "613",
        "ko": "-"
    },
    "percentiles4": {
        "total": "877",
        "ok": "877",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 294,
    "percentage": 98.98989898989899
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3,
    "percentage": 1.0101010101010102
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_027-get-core-va-1179618310": {
        type: "REQUEST",
        name: "027:GET core/validation/unique",
path: "AddEmployee / 027:GET core/validation/unique",
pathFormatted: "req_addemployee---0--1254204984",
stats: {
    "name": "027:GET core/validation/unique",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "765",
        "ok": "765",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "307",
        "ok": "307",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "291",
        "ok": "291",
        "ko": "-"
    },
    "percentiles2": {
        "total": "443",
        "ok": "443",
        "ko": "-"
    },
    "percentiles3": {
        "total": "635",
        "ok": "634",
        "ko": "-"
    },
    "percentiles4": {
        "total": "699",
        "ok": "699",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 297,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_029-get-viewper--694022314": {
        type: "REQUEST",
        name: "029:GET viewPersonalDetails/empNumber/{employeeId}",
path: "AddEmployee / 029:GET viewPersonalDetails/empNumber/{employeeId}",
pathFormatted: "req_addemployee---0--1961727976",
stats: {
    "name": "029:GET viewPersonalDetails/empNumber/{employeeId}",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "62",
        "ok": "62",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1435",
        "ok": "1435",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "269",
        "ok": "269",
        "ko": "-"
    },
    "percentiles1": {
        "total": "460",
        "ok": "460",
        "ko": "-"
    },
    "percentiles2": {
        "total": "634",
        "ok": "634",
        "ko": "-"
    },
    "percentiles3": {
        "total": "946",
        "ok": "946",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1191",
        "ok": "1191",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 263,
    "percentage": 88.55218855218855
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 32,
    "percentage": 10.774410774410773
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2,
    "percentage": 0.6734006734006733
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    }
}

     },"group_employeedetails-1017060244": {
          type: "GROUP",
name: "EmployeeDetails",
path: "EmployeeDetails",
pathFormatted: "group_employeedetails-1017060244",
stats: {
    "name": "EmployeeDetails",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "269",
        "ok": "269",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2083095",
        "ok": "2083095",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8937",
        "ok": "8937",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "120561",
        "ok": "120561",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2121",
        "ok": "2121",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2634",
        "ok": "2634",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3084",
        "ok": "3084",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3652",
        "ok": "3652",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 297,
    "percentage": 100.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
},
contents: {
"req_042-put-employe--580252555": {
        type: "REQUEST",
        name: "042:PUT employees/{employeeId}personal-details",
path: "EmployeeDetails / 042:PUT employees/{employeeId}personal-details",
pathFormatted: "req_employeedetails-636492690",
stats: {
    "name": "042:PUT employees/{employeeId}personal-details",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1264",
        "ok": "1264",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "percentiles1": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles2": {
        "total": "562",
        "ok": "562",
        "ko": "-"
    },
    "percentiles3": {
        "total": "825",
        "ok": "825",
        "ko": "-"
    },
    "percentiles4": {
        "total": "961",
        "ok": "961",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 280,
    "percentage": 94.27609427609428
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 16,
    "percentage": 5.387205387205387
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1,
    "percentage": 0.33670033670033667
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_043-get-index-p-808701720": {
        type: "REQUEST",
        name: "043:GET index.php/pim/viewPimModule",
path: "EmployeeDetails / 043:GET index.php/pim/viewPimModule",
pathFormatted: "req_employeedetails--1707077605",
stats: {
    "name": "043:GET index.php/pim/viewPimModule",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "996",
        "ok": "996",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "340",
        "ok": "340",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "percentiles1": {
        "total": "313",
        "ok": "312",
        "ko": "-"
    },
    "percentiles2": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles3": {
        "total": "718",
        "ok": "718",
        "ko": "-"
    },
    "percentiles4": {
        "total": "962",
        "ok": "962",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 288,
    "percentage": 96.96969696969697
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 9,
    "percentage": 3.0303030303030303
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_043-get-index-p--1995244779": {
        type: "REQUEST",
        name: "043:GET index.php/pim/viewPimModule Redirect 1",
path: "EmployeeDetails / 043:GET index.php/pim/viewPimModule Redirect 1",
pathFormatted: "req_employeedetails--778499534",
stats: {
    "name": "043:GET index.php/pim/viewPimModule Redirect 1",
    "numberOfRequests": {
        "total": "297",
        "ok": "297",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1207",
        "ok": "1207",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "389",
        "ok": "389",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "percentiles1": {
        "total": "373",
        "ok": "373",
        "ko": "-"
    },
    "percentiles2": {
        "total": "551",
        "ok": "551",
        "ko": "-"
    },
    "percentiles3": {
        "total": "795",
        "ok": "795",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1014",
        "ok": "1014",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 284,
    "percentage": 95.62289562289563
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 12,
    "percentage": 4.040404040404041
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1,
    "percentage": 0.33670033670033667
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    }
}

     },"group_employeecontact-410865010": {
          type: "GROUP",
name: "EmployeeContact",
path: "EmployeeContact",
pathFormatted: "group_employeecontact-410865010",
stats: {
    "name": "EmployeeContact",
    "numberOfRequests": {
        "total": "296",
        "ok": "296",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "460",
        "ok": "460",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7019",
        "ok": "7019",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3876",
        "ok": "3876",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1644",
        "ok": "1644",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4394",
        "ok": "4394",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5142",
        "ok": "5142",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5931",
        "ok": "5931",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6611",
        "ok": "6611",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 296,
    "percentage": 100.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
},
contents: {
"req_052-get-viewper-1085567040": {
        type: "REQUEST",
        name: "052:GET viewPersonalDetails/empNumber/{employeeId}",
path: "EmployeeContact / 052:GET viewPersonalDetails/empNumber/{employeeId}",
pathFormatted: "req_employeecontact-1697244607",
stats: {
    "name": "052:GET viewPersonalDetails/empNumber/{employeeId}",
    "numberOfRequests": {
        "total": "296",
        "ok": "296",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "46",
        "ok": "46",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1271",
        "ok": "1271",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles1": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles2": {
        "total": "638",
        "ok": "638",
        "ko": "-"
    },
    "percentiles3": {
        "total": "869",
        "ok": "869",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1054",
        "ok": "1054",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 267,
    "percentage": 90.2027027027027
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 28,
    "percentage": 9.45945945945946
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1,
    "percentage": 0.33783783783783783
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_065-get-contact--249156753": {
        type: "REQUEST",
        name: "065:GET contactDetails/empNumber/{employeeId}",
path: "EmployeeContact / 065:GET contactDetails/empNumber/{employeeId}",
pathFormatted: "req_employeecontact-1676608144",
stats: {
    "name": "065:GET contactDetails/empNumber/{employeeId}",
    "numberOfRequests": {
        "total": "296",
        "ok": "296",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1317",
        "ok": "1317",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "453",
        "ok": "453",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "276",
        "ok": "276",
        "ko": "-"
    },
    "percentiles1": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "percentiles2": {
        "total": "612",
        "ok": "612",
        "ko": "-"
    },
    "percentiles3": {
        "total": "979",
        "ok": "988",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1215",
        "ok": "1215",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 261,
    "percentage": 88.17567567567568
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 30,
    "percentage": 10.135135135135135
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 5,
    "percentage": 1.6891891891891893
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_073-get-contact--920346353": {
        type: "REQUEST",
        name: "073:GET contact-details/validation/work-emails",
path: "EmployeeContact / 073:GET contact-details/validation/work-emails",
pathFormatted: "req_employeecontact--1351176690",
stats: {
    "name": "073:GET contact-details/validation/work-emails",
    "numberOfRequests": {
        "total": "296",
        "ok": "296",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "903",
        "ok": "903",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "337",
        "ok": "337",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "209",
        "ok": "209",
        "ko": "-"
    },
    "percentiles1": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "percentiles2": {
        "total": "481",
        "ok": "481",
        "ko": "-"
    },
    "percentiles3": {
        "total": "719",
        "ok": "719",
        "ko": "-"
    },
    "percentiles4": {
        "total": "826",
        "ok": "826",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 293,
    "percentage": 98.98648648648648
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3,
    "percentage": 1.0135135135135136
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    },"req_074-get-contact--1945040274": {
        type: "REQUEST",
        name: "074:GET contact-details/validation/work-emails",
path: "EmployeeContact / 074:GET contact-details/validation/work-emails",
pathFormatted: "req_employeecontact-1919096685",
stats: {
    "name": "074:GET contact-details/validation/work-emails",
    "numberOfRequests": {
        "total": "296",
        "ok": "296",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1067",
        "ok": "1067",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "344",
        "ok": "344",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "203",
        "ok": "203",
        "ko": "-"
    },
    "percentiles1": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles2": {
        "total": "476",
        "ok": "476",
        "ko": "-"
    },
    "percentiles3": {
        "total": "683",
        "ok": "683",
        "ko": "-"
    },
    "percentiles4": {
        "total": "920",
        "ok": "920",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 291,
    "percentage": 98.3108108108108
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 5,
    "percentage": 1.6891891891891893
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.08",
        "ok": "0.08",
        "ko": "-"
    }
}
    }
}

     },"group_logout--1097329270": {
          type: "GROUP",
name: "logout",
path: "logout",
pathFormatted: "group_logout--1097329270",
stats: {
    "name": "logout",
    "numberOfRequests": {
        "total": "3094",
        "ok": "3092",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "124",
        "ok": "124",
        "ko": "2082058"
    },
    "maxResponseTime": {
        "total": "2082850",
        "ok": "2082850",
        "ko": "2082535"
    },
    "meanResponseTime": {
        "total": "3843",
        "ok": "2498",
        "ko": "2082297"
    },
    "standardDeviation": {
        "total": "74788",
        "ok": "52922",
        "ko": "239"
    },
    "percentiles1": {
        "total": "1189",
        "ok": "1188",
        "ko": "2082535"
    },
    "percentiles2": {
        "total": "1613",
        "ok": "1612",
        "ko": "2082535"
    },
    "percentiles3": {
        "total": "2112",
        "ok": "2112",
        "ko": "2082535"
    },
    "percentiles4": {
        "total": "2575",
        "ok": "2558",
        "ko": "2082535"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 978,
    "percentage": 31.60956690368455
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 590,
    "percentage": 19.069166127989657
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1524,
    "percentage": 49.256625727213965
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0.06464124111182934
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
},
contents: {
"req_013-get-index-p-386043916": {
        type: "REQUEST",
        name: "013:GET index.php/auth/logout",
path: "logout / 013:GET index.php/auth/logout",
pathFormatted: "req_logout---013-ge--257150651",
stats: {
    "name": "013:GET index.php/auth/logout",
    "numberOfRequests": {
        "total": "3094",
        "ok": "3094",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "25",
        "ok": "25",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1052",
        "ok": "1052",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "178",
        "ok": "178",
        "ko": "-"
    },
    "percentiles1": {
        "total": "260",
        "ok": "261",
        "ko": "-"
    },
    "percentiles2": {
        "total": "403",
        "ok": "401",
        "ko": "-"
    },
    "percentiles3": {
        "total": "608",
        "ok": "604",
        "ko": "-"
    },
    "percentiles4": {
        "total": "765",
        "ok": "742",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3074,
    "percentage": 99.35358758888171
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 20,
    "percentage": 0.6464124111182934
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "-"
    }
}
    },"req_013-get-index-p--2032281183": {
        type: "REQUEST",
        name: "013:GET index.php/auth/logout Redirect 1",
path: "logout / 013:GET index.php/auth/logout Redirect 1",
pathFormatted: "req_logout---013-ge--1457296696",
stats: {
    "name": "013:GET index.php/auth/logout Redirect 1",
    "numberOfRequests": {
        "total": "3094",
        "ok": "3092",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "2081696"
    },
    "maxResponseTime": {
        "total": "2082012",
        "ok": "1195",
        "ko": "2082012"
    },
    "meanResponseTime": {
        "total": "1661",
        "ok": "316",
        "ko": "2081854"
    },
    "standardDeviation": {
        "total": "52906",
        "ok": "205",
        "ko": "158"
    },
    "percentiles1": {
        "total": "283",
        "ok": "283",
        "ko": "2082012"
    },
    "percentiles2": {
        "total": "456",
        "ok": "457",
        "ko": "2082012"
    },
    "percentiles3": {
        "total": "686",
        "ok": "682",
        "ko": "2082012"
    },
    "percentiles4": {
        "total": "867",
        "ok": "841",
        "ko": "2082012"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3028,
    "percentage": 97.86683904330962
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 64,
    "percentage": 2.068519715578539
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0.06464124111182934
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.79",
        "ok": "0.79",
        "ko": "0"
    }
}
    }
}

     },"group_searchemployee--1947052906": {
          type: "GROUP",
name: "SearchEmployee",
path: "SearchEmployee",
pathFormatted: "group_searchemployee--1947052906",
stats: {
    "name": "SearchEmployee",
    "numberOfRequests": {
        "total": "2800",
        "ok": "2386",
        "ko": "414"
    },
    "minResponseTime": {
        "total": "76",
        "ok": "76",
        "ko": "99"
    },
    "maxResponseTime": {
        "total": "2081790",
        "ok": "2101",
        "ko": "2081790"
    },
    "meanResponseTime": {
        "total": "2189",
        "ok": "677",
        "ko": "10900"
    },
    "standardDeviation": {
        "total": "55599",
        "ok": "374",
        "ko": "144280"
    },
    "percentiles1": {
        "total": "702",
        "ok": "665",
        "ko": "841"
    },
    "percentiles2": {
        "total": "964",
        "ok": "946",
        "ko": "1037"
    },
    "percentiles3": {
        "total": "1319",
        "ok": "1308",
        "ko": "1381"
    },
    "percentiles4": {
        "total": "1644",
        "ok": "1627",
        "ko": "1811"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 318,
    "percentage": 11.357142857142858
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 787,
    "percentage": 28.107142857142858
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1281,
    "percentage": 45.75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 414,
    "percentage": 14.785714285714285
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.71",
        "ok": "0.61",
        "ko": "0.11"
    }
},
contents: {
"req_050-get-api-pim-1146323900": {
        type: "REQUEST",
        name: "050:GET api/pim/employees",
path: "SearchEmployee / 050:GET api/pim/employees",
pathFormatted: "req_searchemployee---1740824959",
stats: {
    "name": "050:GET api/pim/employees",
    "numberOfRequests": {
        "total": "2800",
        "ok": "2798",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "2081621"
    },
    "maxResponseTime": {
        "total": "2081790",
        "ok": "1164",
        "ko": "2081790"
    },
    "meanResponseTime": {
        "total": "1836",
        "ok": "349",
        "ko": "2081706"
    },
    "standardDeviation": {
        "total": "55607",
        "ok": "208",
        "ko": "85"
    },
    "percentiles1": {
        "total": "331",
        "ok": "330",
        "ko": "2081790"
    },
    "percentiles2": {
        "total": "490",
        "ok": "490",
        "ko": "2081790"
    },
    "percentiles3": {
        "total": "725",
        "ok": "722",
        "ko": "2081790"
    },
    "percentiles4": {
        "total": "926",
        "ok": "917",
        "ko": "2081790"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2721,
    "percentage": 97.17857142857143
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 77,
    "percentage": 2.75
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0.07142857142857142
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.71",
        "ok": "0.71",
        "ko": "0"
    }
}
    },"req_051-get-api-pim--1903878915": {
        type: "REQUEST",
        name: "051:GET api/pim/employees",
path: "SearchEmployee / 051:GET api/pim/employees",
pathFormatted: "req_searchemployee---496060478",
stats: {
    "name": "051:GET api/pim/employees",
    "numberOfRequests": {
        "total": "2798",
        "ok": "2386",
        "ko": "412"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "45"
    },
    "maxResponseTime": {
        "total": "1327",
        "ok": "1327",
        "ko": "1272"
    },
    "meanResponseTime": {
        "total": "354",
        "ok": "342",
        "ko": "422"
    },
    "standardDeviation": {
        "total": "213",
        "ok": "215",
        "ko": "192"
    },
    "percentiles1": {
        "total": "330",
        "ok": "312",
        "ko": "397"
    },
    "percentiles2": {
        "total": "490",
        "ok": "476",
        "ko": "544"
    },
    "percentiles3": {
        "total": "747",
        "ok": "745",
        "ko": "749"
    },
    "percentiles4": {
        "total": "936",
        "ok": "931",
        "ko": "940"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2310,
    "percentage": 82.55897069335239
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 74,
    "percentage": 2.6447462473195142
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2,
    "percentage": 0.07147962830593281
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 412,
    "percentage": 14.72480343102216
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.71",
        "ok": "0.61",
        "ko": "0.1"
    }
}
    }
}

     }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
